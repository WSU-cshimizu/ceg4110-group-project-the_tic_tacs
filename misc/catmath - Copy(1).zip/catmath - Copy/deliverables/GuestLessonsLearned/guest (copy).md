# Guest Lecture Response
* **Guest Lecturer:** `blank`
* **Company:** `blank`
* **Date:** Thursday, 7 November 2024

## Pertinent Questions
* Question 1

* Question 2

## Lessons Learned
* Text paragraph.

* Text paragraph.

* Text paragraph.

## Difference between definitions taught in class and provided by the Guest Lecturer

* 

* 


