# Guest Lecture Response

* **Guest Lecturer:** Chris Schramek 
* **Company:** Winsupply
* **Date:** Thursday, 24 October 2024

## Pertinent Questions

* What agile frameworks does his team use? Scrum or agile depending on the team and the project.

* 

## Lessons Learned

* 

* 

* 

* 

## Difference between definitions taught in class and provided by the Guest Lecturer

* 

* 

