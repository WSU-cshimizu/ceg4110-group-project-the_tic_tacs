# Guest Lecture Response
* **Guest Lecturer:** `blank`
* **Company:** `blank`
* **Date:** `blank`

## Pertinent Questions
* Question 1
* Question 2

## Lessons Learned
Text paragraph.

Text paragraph.

Text paragraph.