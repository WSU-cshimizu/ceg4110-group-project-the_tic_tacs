# The Tic-Tacs

Jessica Venema 
 - Undergrad, Senior

----------
Abit Kumar Mahato
    - International Grad Student, First Semester

----------
Ben Hawk
 - Undergraduate, Junior
   
----------

Ethan Schultz
 - Undergrad, Senior
   
----------
 
Liliane Owens
 - undergrad, senior

# Navigation:

* The Deliverables folder contains obviously named folder which contain the required documents and their assets.
